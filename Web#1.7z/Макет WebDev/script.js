menu.onclick = function myFunction() {
	let x = document.getElementById('myTopnav');

	switch(x.className) {
		case 'topnav responsitive': 
									x.className = "topnav";
									break;
		case 'topnav': 
									x.className += " responsitive";
									break;
	}		
/*
	if (x.className==="topnav") {
			x.className += " responsitive";
	}*/
}